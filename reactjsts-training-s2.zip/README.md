# Getting Started with ReactJS + Typescript

This project is intended for employee training within the Sync

